"use client";

import { ArrowLeft, Maximize2, Menu } from "lucide-react";
import type { ReactNode } from "react";

export function NotebookExpandButton({
  onClick,
  className = "",
}: {
  onClick: () => void;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-md p-1 text-muted hover:bg-white/10 hover:text-white ${className}`}
      aria-label="拡大"
    >
      <Maximize2 size={16} />
    </button>
  );
}

export function ComposerExpandOverlay({
  open,
  onClose,
  children,
}: {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="absolute inset-0 z-30 flex min-h-0 flex-col bg-[#0b1220]">
      <div className="flex shrink-0 items-center gap-2 px-3 py-2">
        <button
          type="button"
          onClick={onClose}
          className="rounded-md p-1.5 text-muted hover:bg-white/10 hover:text-white"
          aria-label="メニュー"
        >
          <Menu size={20} />
        </button>
        <button
          type="button"
          onClick={onClose}
          className="inline-flex items-center gap-1 rounded-full bg-white/10 px-3 py-1.5 text-xs font-bold text-white hover:bg-white/15"
        >
          <ArrowLeft size={14} />
          完了
        </button>
      </div>
      <div className="flex min-h-0 flex-1 flex-col">{children}</div>
    </div>
  );
}
